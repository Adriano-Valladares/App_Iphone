//
//  ServicioWeb.swift
//  PruebaJuegoNonagramas
//
//  Created by Alumno on 22/09/25.
//

import SwiftUI

struct ServicioWeb: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ServicioWeb()
}
